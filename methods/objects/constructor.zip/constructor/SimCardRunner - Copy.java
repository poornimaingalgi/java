class SimCardRunner {
    public static void main(String[] args) {
        SimCard simCard0 = new SimCard("Jio", "299 1.5GB/day", 1);
        simCard0.displayDetails();
        System.out.println();

        SimCard simCard1 = new SimCard("Airtel", "399 2GB/day", 2);
        simCard1.displayDetails();
        System.out.println();

        SimCard simCard2 = new SimCard("Vodafone", "199 1GB/day", 3);
        simCard2.displayDetails();
        System.out.println();

        SimCard simCard3 = new SimCard("Idea", "149 1.5GB/day", 4);
        simCard3.displayDetails();
        System.out.println();

        SimCard simCard4 = new SimCard("BSNL", "99 1GB/day", 5);
        simCard4.displayDetails();
        System.out.println();

        SimCard simCard5 = new SimCard("T-Mobile", "50 Unlimited", 6);
        simCard5.displayDetails();
        System.out.println();

        SimCard simCard6 = new SimCard("Verizon", "70 Unlimited", 7);
        simCard6.displayDetails();
        System.out.println();

        SimCard simCard7 = new SimCard("Sprint", "60 Unlimited", 8);
        simCard7.displayDetails();
        System.out.println();

        SimCard simCard8 = new SimCard("AT&T", "65 Unlimited", 9);
        simCard8.displayDetails();
        System.out.println();

        SimCard simCard9 = new SimCard("MetroPCS", "40 Unlimited", 10);
        simCard9.displayDetails();
        System.out.println();

        SimCard simCard10 = new SimCard("Cricket", "55 Unlimited", 11);
        simCard10.displayDetails();
        System.out.println();

        SimCard simCard11 = new SimCard("Boost Mobile", "35 Unlimited", 12);
        simCard11.displayDetails();
        System.out.println();

        SimCard simCard12 = new SimCard("Virgin Mobile", "30 Unlimited", 13);
        simCard12.displayDetails();
        System.out.println();

        SimCard simCard13 = new SimCard("US Cellular", "45 Unlimited", 14);
        simCard13.displayDetails();
        System.out.println();

        SimCard simCard14 = new SimCard("Republic Wireless", "20 1GB", 15);
        simCard14.displayDetails();
        System.out.println();
    }
}