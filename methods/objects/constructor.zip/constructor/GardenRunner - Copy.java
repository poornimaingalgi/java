class GardenRunner {
    public static void main(String[] args) {
       
        Garden garden0 = new Garden("Lalbagh", "Bangalore", 1);
        garden0.gettingFreshAir();
        System.out.println();

        Garden garden1 = new Garden("NTR Garden", "Hyderabad", 2);
        garden1.gettingFreshAir();
        System.out.println();

        Garden garden2 = new Garden("Botanical Garden", "Pune", 3);
        garden2.gettingFreshAir();
        System.out.println();

        Garden garden3 = new Garden("Rose Garden", "Indo-Africa", 4);
        garden3.gettingFreshAir();
        System.out.println();

        Garden garden4 = new Garden("Cubbon Park", "Bengaluru", 5);
        garden4.gettingFreshAir();
        System.out.println();

        Garden garden5 = new Garden("Lumbini Garden", "Bengaluru", 6);
        garden5.gettingFreshAir();
        System.out.println();

        Garden garden6 = new Garden("Mughal Garden", "Delhi", 7);
        garden6.gettingFreshAir();
        System.out.println();

        Garden garden7 = new Garden("Alexander Garden", "Versailles", 8);
        garden7.gettingFreshAir();
        System.out.println();

        Garden garden8 = new Garden("Lodhi Garden", "Delhi", 9);
        garden8.gettingFreshAir();
        System.out.println();

        Garden garden9 = new Garden("Priyadarshini Park", "Mumbai", 10);
        garden9.gettingFreshAir();
        System.out.println();

        Garden garden10 = new Garden("Ayrlies Garden", "Autumn", 11);
        garden10.gettingFreshAir();
        System.out.println();

        Garden garden11 = new Garden("Five Garden", "Karnataka", 12);
        garden11.gettingFreshAir();
        System.out.println();

        Garden garden12 = new Garden("Brindavan Garden", "Mysuru", 13);
        garden12.gettingFreshAir();
        System.out.println();

        Garden garden13 = new Garden("Hanging Garden", "Mumbai", 14);
        garden13.gettingFreshAir();
        System.out.println();

        Garden garden14 = new Garden("Auroville Botanical Garden", "Tamil Nadu", 15);
        garden14.gettingFreshAir();
        System.out.println();
    }
}