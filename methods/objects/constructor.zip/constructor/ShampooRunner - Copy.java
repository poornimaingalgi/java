class ShampooRunner {
    public static void main(String[] args) {
        Shampoo shampoo0 = new Shampoo("Head & Shoulders", 200, 1, "Anti-Dandruff", 6.99, "2023-01-01", "2025-01-01");
        shampoo0.displayDetails();
        System.out.println();

        Shampoo shampoo1 = new Shampoo("Pantene", 250, 2, "Volumizing", 5.49, "2023-02-01", "2025-02-01");
        shampoo1.displayDetails();
        System.out.println();

        Shampoo shampoo2 = new Shampoo("Dove", 300, 3, "Moisturizing", 4.99, "2023-03-01", "2025-03-01");
        shampoo2.displayDetails();
        System.out.println();

        Shampoo shampoo3 = new Shampoo("Tresemme", 400, 4, "Smooth & Silky", 7.99, "2023-04-01", "2025-04-01");
        shampoo3.displayDetails();
        System.out.println();

        Shampoo shampoo4 = new Shampoo("Garnier", 150, 5, "Fructis", 3.99, "2023-05-01", "2025-05-01");
        shampoo4.displayDetails();
        System.out.println();

        Shampoo shampoo5 = new Shampoo("Herbal Essences", 350, 6, "Bio:Renew", 8.49, "2023-06-01", "2025-06-01");
        shampoo5.displayDetails();
        System.out.println();

        Shampoo shampoo6 = new Shampoo("L'Oreal", 500, 7, "Color Protect", 9.99, "2023-07-01", "2025-07-01");
        shampoo6.displayDetails();
        System.out.println();

        Shampoo shampoo7 = new Shampoo("Matrix", 450, 8, "Biolage", 10.99, "2023-08-01", "2025-08-01");
        shampoo7.displayDetails();
        System.out.println();

        Shampoo shampoo8 = new Shampoo("Nivea", 300, 9, "Men Power", 5.99, "2023-09-01", "2025-09-01");
        shampoo8.displayDetails();
        System.out.println();

        Shampoo shampoo9 = new Shampoo("Axe", 250, 10, "Daily Clean", 4.49, "2023-10-01", "2025-10-01");
        shampoo9.displayDetails();
        System.out.println();

        Shampoo shampoo10 = new Shampoo("OGX", 300, 11, "Coconut Milk", 6.49, "2023-11-01", "2025-11-01");
        shampoo10.displayDetails();
        System.out.println();

        Shampoo shampoo11 = new Shampoo("Sunsilk", 200, 12, "Black Shine", 3.99, "2023-12-01", "2025-12-01");
        shampoo11.displayDetails();
        System.out.println();

        Shampoo shampoo12 = new Shampoo("Clinic Plus", 180, 13, "Strong & Long", 2.99, "2023-01-15", "2025-01-15");
        shampoo12.displayDetails();
        System.out.println();

        Shampoo shampoo13 = new Shampoo("Johnson's Baby", 500, 14, "No More Tears", 4.99, "2023-02-15", "2025-02-15");
        shampoo13.displayDetails();
        System.out.println();

        Shampoo shampoo14 = new Shampoo("Sebamed", 400, 15, "Anti-Hairloss", 11.99, "2023-03-15", "2025-03-15");
        shampoo14.displayDetails();
        System.out.println();
    }
}