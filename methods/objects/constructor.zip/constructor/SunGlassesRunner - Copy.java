class SunGlassesRunner {
    public static void main(String[] args) {
        SunGlasses sunGlasses0 = new SunGlasses("Ray-Ban", "Aviator", 1, 150, false);
        sunGlasses0.displayDetails();
        System.out.println();

        SunGlasses sunGlasses1 = new SunGlasses("Oakley", "Sport", 2, 200, true);
        sunGlasses1.displayDetails();
        System.out.println();

        SunGlasses sunGlasses2 = new SunGlasses("Gucci", "Fashion", 3, 300, false);
        sunGlasses2.displayDetails();
        System.out.println();

        SunGlasses sunGlasses3 = new SunGlasses("Prada", "Classic", 4, 250, true);
        sunGlasses3.displayDetails();
        System.out.println();

        SunGlasses sunGlasses4 = new SunGlasses("Versace", "Luxury", 5, 400, false);
        sunGlasses4.displayDetails();
        System.out.println();

        SunGlasses sunGlasses5 = new SunGlasses("Dolce & Gabbana", "Fashion", 6, 350, true);
        sunGlasses5.displayDetails();
        System.out.println();

        SunGlasses sunGlasses6 = new SunGlasses("Armani", "Classic", 7, 275, false);
        sunGlasses6.displayDetails();
        System.out.println();

        SunGlasses sunGlasses7 = new SunGlasses("Tom Ford", "Luxury", 8, 450, true);
        sunGlasses7.displayDetails();
        System.out.println();

        SunGlasses sunGlasses8 = new SunGlasses("Fendi", "Fashion", 9, 320, false);
        sunGlasses8.displayDetails();
        System.out.println();

        SunGlasses sunGlasses9 = new SunGlasses("Chanel", "Classic", 10, 500, true);
        sunGlasses9.displayDetails();
        System.out.println();

        SunGlasses sunGlasses10 = new SunGlasses("Burberry", "Fashion", 11, 375, false);
        sunGlasses10.displayDetails();
        System.out.println();

        SunGlasses sunGlasses11 = new SunGlasses("Dior", "Luxury", 12, 420, true);
        sunGlasses11.displayDetails();
        System.out.println();

        SunGlasses sunGlasses12 = new SunGlasses("Bvlgari", "Classic", 13, 280, false);
        sunGlasses12.displayDetails();
        System.out.println();

        SunGlasses sunGlasses13 = new SunGlasses("Cartier", "Luxury", 14, 600, true);
        sunGlasses13.displayDetails();
        System.out.println();

        SunGlasses sunGlasses14 = new SunGlasses("Tiffany & Co.", "Fashion", 15, 340, false);
        sunGlasses14.displayDetails();
        System.out.println();
    }
}