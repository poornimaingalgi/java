class PenRunner {
    public static void main(String[] args) {
        Pen pen0 = new Pen("Reynolds", 20.00, "Blue", 1);
        pen0.displayDetails();
        System.out.println();

        Pen pen1 = new Pen("Parker", 30.00, "Pink", 2);
        pen1.displayDetails();
        System.out.println();

        Pen pen2 = new Pen("Cello", 10.00, "Black", 3);
        pen2.displayDetails();
        System.out.println();

        Pen pen3 = new Pen("Pilot", 50.00, "Red", 4);
        pen3.displayDetails();
        System.out.println();

        Pen pen4 = new Pen("Camlin", 15.00, "Green", 5);
        pen4.displayDetails();
        System.out.println();

        Pen pen5 = new Pen("Faber-Castell", 25.00, "Blue", 6);
        pen5.displayDetails();
        System.out.println();

        Pen pen6 = new Pen("Lamy", 100.00, "Black", 7);
        pen6.displayDetails();
        System.out.println();

        Pen pen7 = new Pen("Mont Blanc", 200.00, "White", 8);
        pen7.displayDetails();
        System.out.println();

        Pen pen8 = new Pen("Cross", 80.00, "Gold", 9);
        pen8.displayDetails();
        System.out.println();

        Pen pen9 = new Pen("Sheaffer", 60.00, "Silver", 10);
        pen9.displayDetails();
        System.out.println();

        Pen pen10 = new Pen("Waterman", 120.00, "Blue", 11);
        pen10.displayDetails();
        System.out.println();

        Pen pen11 = new Pen("BIC", 5.00, "Red", 12);
        pen11.displayDetails();
        System.out.println();

        Pen pen12 = new Pen("Uni-Ball", 20.00, "Black", 13);
        pen12.displayDetails();
        System.out.println();

        Pen pen13 = new Pen("Sharpie", 15.00, "Green", 14);
        pen13.displayDetails();
        System.out.println();

        Pen pen14 = new Pen("Staedtler", 25.00, "Blue", 15);
        pen14.displayDetails();
        System.out.println();
    }
}