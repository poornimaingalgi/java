class AmusementParkRunner {
    public static void main(String[] args) {
       
        AmusementPark park0 = new AmusementPark("Disneyland", "Theme Park", 1, 5000, 50);
        park0.Play();
        System.out.println();

        AmusementPark park1 = new AmusementPark("Universal Studios", "Movie Park", 2, 4500, 40);
        park1.Play();
        System.out.println();

        AmusementPark park2 = new AmusementPark("Six Flags", "Adventure Park", 3, 3000, 60);
        park2.Play();
        System.out.println();

        AmusementPark park3 = new AmusementPark("SeaWorld", "Marine Park", 4, 3500, 30);
        park3.Play();
        System.out.println();

        AmusementPark park4 = new AmusementPark("Legoland", "Theme Park", 5, 4000, 25);
        park4.Play();
        System.out.println();

        AmusementPark park5 = new AmusementPark("Wonderla", "Adventure Park", 6, 2500, 20);
        park5.Play();
        System.out.println();

        AmusementPark park6 = new AmusementPark("EsselWorld", "Amusement Park", 7, 2000, 45);
        park6.Play();
        System.out.println();

        AmusementPark park7 = new AmusementPark("Ramoji Film City", "Movie Park", 8, 3500, 35);
        park7.Play();
        System.out.println();

        AmusementPark park8 = new AmusementPark("Imagica", "Theme Park", 9, 4200, 55);
        park8.Play();
        System.out.println();

        AmusementPark park9 = new AmusementPark("Adventure Island", "Adventure Park", 10, 2200, 28);
        park9.Play();
        System.out.println();

        AmusementPark park10 = new AmusementPark("Kingdom of Dreams", "Theme Park", 11, 3800, 20);
        park10.Play();
        System.out.println();

        AmusementPark park11 = new AmusementPark("Nicco Park", "Amusement Park", 12, 1500, 18);
        park11.Play();
        System.out.println();

        AmusementPark park12 = new AmusementPark("Aquatica", "Water Park", 13, 2800, 15);
        park12.Play();
        System.out.println();

        AmusementPark park13 = new AmusementPark("Kidzania", "Educational Park", 14, 2600, 22);
        park13.Play();
        System.out.println();

        AmusementPark park14 = new AmusementPark("Fun World", "Amusement Park", 15, 3000, 40);
        park14.Play();
        System.out.println();
    }
}