class AgarbathiRunner{

	public static void main(String agarbati[]){
		
		Agarbathi ref = new Agarbathi("Cycle Pure", 50, 1, "Sandalwood", 58.00 );
		ref.getAgarbathi();
		System.out.println("");
		
		Agarbathi ref1 = new Agarbathi("Moksha", 30, 2, "Premium", 100.0 );
		ref1.getAgarbathi();
		System.out.println("");
		
		Agarbathi ref2 = new Agarbathi("Zed Black", 25, 3, "Regular", 60.0 );
		ref2.getAgarbathi();
		System.out.println("");
		
		Agarbathi ref3 = new Agarbathi("Mangaldeep",  15, 4, "Regular", 40.0);
		ref3.getAgarbathi();
		System.out.println("");
		
		Agarbathi ref4 = new Agarbathi("Hem",  10, 5, "Premium", 80.0);
		ref4.getAgarbathi();
		System.out.println("");
		
		Agarbathi ref5 = new Agarbathi("Darshan",  50, 6, "Regular", 90.0);
		ref5.getAgarbathi();
		System.out.println("");
		
		Agarbathi ref6 = new Agarbathi("Satya", 40, 7, "Premium", 150.0 );
		ref6.getAgarbathi();
		System.out.println("");
		
		Agarbathi ref7 = new Agarbathi("Hari Darshan",  35, 8, "Regular", 70.0 );
		ref7.getAgarbathi();
		System.out.println("");
		
		Agarbathi ref8 = new Agarbathi("Bic",  25, 9, "Regular", 55.0 );
		ref8.getAgarbathi();
		System.out.println("");
		
		Agarbathi ref9 = new Agarbathi("Sugandha",  20, 10, "Premium", 120.0 );
		ref9.getAgarbathi();
		System.out.println("");
		
		Agarbathi ref10 = new Agarbathi("Goloka",  30, 11, "Regular", 75.0) ;
		ref10.getAgarbathi();
		System.out.println("");
		
		Agarbathi ref11 = new Agarbathi("Parimal",  18, 12, "Regular", 65.0 );
		ref11.getAgarbathi();
		System.out.println("");
		
		Agarbathi ref12 = new Agarbathi("Bhimseni",  12, 13, "Premium", 85.0 );
		ref12.getAgarbathi();
		System.out.println("");
		
		Agarbathi ref13 = new Agarbathi("Om Shanti",  22, 14, "Regular", 50.0 );
		ref13.getAgarbathi();
		System.out.println("");
		
		Agarbathi ref14 = new Agarbathi("Chandan",  28, 15, "Premium", 95.0 );
		ref14.getAgarbathi();
		System.out.println("");
		
		
	
	
	}




}