class NewsPaperRunner {
    public static void main(String[] args) {
        NewsPaper newspaper0 = new NewsPaper("Hindustan", 29, 1, "Hindi");
        newspaper0.currentAffairs();
        System.out.println();

        NewsPaper newspaper1 = new NewsPaper("Indian Express", 18, 2, "English");
        newspaper1.currentAffairs();
        System.out.println();

        NewsPaper newspaper2 = new NewsPaper("Vijay Karnataka", 30, 3, "Kannada");
        newspaper2.currentAffairs();
        System.out.println();

        NewsPaper newspaper3 = new NewsPaper("Kannada Prabha", 15, 4, "Kannada");
        newspaper3.currentAffairs();
        System.out.println();

        NewsPaper newspaper4 = new NewsPaper("VijayaVani", 28, 5, "Kannada");
        newspaper4.currentAffairs();
        System.out.println();

        NewsPaper newspaper5 = new NewsPaper("Prajavani", 27, 6, "Kannada");
        newspaper5.currentAffairs();
        System.out.println();

        NewsPaper newspaper6 = new NewsPaper("The Hindu", 30, 7, "English");
        newspaper6.currentAffairs();
        System.out.println();

        NewsPaper newspaper7 = new NewsPaper("The Times of India", 18, 8, "English");
        newspaper7.currentAffairs();
        System.out.println();

        NewsPaper newspaper8 = new NewsPaper("The Indian Express", 101, 9, "English");
        newspaper8.currentAffairs();
        System.out.println();

        NewsPaper newspaper9 = new NewsPaper("Amar Ujala", 14, 10, "Hindi");
        newspaper9.currentAffairs();
        System.out.println();

        NewsPaper newspaper10 = new NewsPaper("Rajasthan Patrika", 8, 11, "Hindi");
        newspaper10.currentAffairs();
        System.out.println();

        NewsPaper newspaper11 = new NewsPaper("Deccan Herald", 10, 12, "English");
        newspaper11.currentAffairs();
        System.out.println();

        NewsPaper newspaper12 = new NewsPaper("The Economic Times", 26, 13, "English");
        newspaper12.currentAffairs();
        System.out.println();

        NewsPaper newspaper13 = new NewsPaper("Blitz", 29, 14, "Telugu");
        newspaper13.currentAffairs();
        System.out.println();

        NewsPaper newspaper14 = new NewsPaper("Musalman", 10, 15, "Urdu");
        newspaper14.currentAffairs();
        System.out.println();
    }
}